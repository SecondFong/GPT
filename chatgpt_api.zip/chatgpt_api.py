'''
flask, openai, redis
'''
from flask import Flask, request, jsonify
import openai
import redis
import os
import json
# https://platform.openai.com/docs/api-reference/authentication
# need to exprot OPENAI_API_KEY='the chatgpt api key'
openai.api_key = os.environ["OPENAI_API_KEY"]
app = Flask(__name__)
# use redis to save the chat history
r = redis.Redis(host='localhost', port=6379, db=0)


# chat gpt model name
model_engine = "gpt-3.5-turbo"
@app.route("/chat", methods=["POST"])
def chat():

    # get user input
    user_message = request.json["message"]
    try:
        # load user chat history
        message: list = json.loads(r.get('history'))
    except:
        message = []
    print('history:')
    print(message)
    # add user input
    message.append({"role": "user", "content": user_message})
    # call api
    response = openai.ChatCompletion.create(model=model_engine,
                                            messages=message)
    generated_text = ''
    # save gpt response
    if 'choices' in response:
        generated_text = response['choices'][0]['message']['content']
        role = response['choices'][0]['message']['role']
        message.append({"role": role, "content": generated_text})
        r.set('history', json.dumps(message))
    # return response
    return jsonify({"message": generated_text})

if __name__ == "__main__":
    app.run()
